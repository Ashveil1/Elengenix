"""elengenix/reports/pdf.py — Markdown → PDF renderer (ReportLab).

This module ports PentAGI's ``frontend/src/lib/report/report-pdf.tsx``
(`@react-pdf/renderer` based) to a Python equivalent built on top of
**ReportLab**. The upstream React implementation:

* Registers three font families (NotoSans / NotoSansMono / NotoSansSC)
  with their italic / bold variants.
* Disables word hyphenation (breaks CJK and Cyrillic incorrectly).
* Splits every text run into alternating non-CJK / CJK segments so
  each segment renders with the matching font family (CJK fonts have
  no true italic — italic is dropped for those segments).
* Substitutes a fixed set of status / context emoji glyphs with
  readable ASCII ``[TAG]`` placeholders because ``@react-pdf/renderer``
  has spotty emoji glyph support.

The Python port preserves every behaviour above. ReportLab is loaded
lazily so importing this module does not pay the cost unless a PDF is
actually rendered.

Public API
----------
* :func:`render_to_pdf`           — render Markdown text to a PDF file.
* :func:`render_to_pdf_bytes`     — render Markdown text to ``bytes``.
* :func:`parse_markdown_tokens`   — typed-token list (``markdown-it-py``).
* :func:`split_by_cjk`            — split text into CJK / non-CJK segments.
* :data:`EMOJI_SUBSTITUTIONS`     — emoji → ``[TAG]`` mapping.
* :data:`HEADING_FONT_SIZES`      — H1=16, H2=14, H3=13, H4=12, H5=11, H6=10.
"""

from __future__ import annotations

import logging
import os
import re
import sys
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

logger = logging.getLogger("elengenix.reports.pdf")


# ---------------------------------------------------------------------------
# Font configuration — paths are searched in priority order; first match wins.
# ---------------------------------------------------------------------------

#: Candidate search paths for each font family. The original PentAGI ships
#: ``NotoSans-Regular.ttf`` etc. inside the frontend bundle; on Linux servers
#: we fall back to Liberation Sans (Latin/Cyrillic) and NotoSerifSC (CJK).
#: NotoSerifSC is used in place of NotoSansSC because the only static Noto
#: SC font available on the host is the variable-weight ``NotoSansSC[wght].ttf``
#: which ReportLab cannot load directly.
FONT_SEARCH_PATHS: dict[str, dict[str, list[str]]] = {
    "NotoSans": {
        "regular": [
            "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSans-Regular.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/usr/share/fonts/truetype/chinese/LiberationSans-Regular.ttf",
        ],
        "bold": [
            "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        ],
        "italic": [
            "/usr/share/fonts/truetype/noto/NotoSans-Italic.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSans-Italic.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Italic.ttf",
        ],
        "bolditalic": [
            "/usr/share/fonts/truetype/noto/NotoSans-BoldItalic.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSans-BoldItalic.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-BoldItalic.ttf",
        ],
    },
    "NotoSansMono": {
        "regular": [
            "/usr/share/fonts/truetype/noto/NotoSansMono-Regular.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSansMono-Regular.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
            "/usr/share/fonts/truetype/chinese/LiberationMono-Regular.ttf",
        ],
        "bold": [
            "/usr/share/fonts/truetype/noto/NotoSansMono-Bold.ttf",
            "/usr/share/fonts/truetype/chinese/NotoSansMono-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf",
            "/usr/share/fonts/truetype/chinese/SarasaMonoSC-Bold.ttf",
        ],
    },
    "NotoSansSC": {
        "regular": [
            "/usr/share/fonts/truetype/chinese/NotoSansSC-Regular.ttf",
            "/usr/share/fonts/truetype/noto-serif-sc/NotoSerifSC-Regular.ttf",
            "/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf",
        ],
        "bold": [
            "/usr/share/fonts/truetype/chinese/NotoSansSC-Bold.ttf",
            "/usr/share/fonts/truetype/noto-serif-sc/NotoSerifSC-Bold.ttf",
            "/usr/share/fonts/truetype/chinese/SarasaMonoSC-Bold.ttf",
        ],
    },
}


def _first_existing(paths: Sequence[str]) -> str | None:
    """Return the first path in ``paths`` that exists on disk, else ``None``."""
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None


# ---------------------------------------------------------------------------
# Emoji substitution table — verbatim from PentAGI's report-pdf.tsx.
# ---------------------------------------------------------------------------

#: Maps emoji glyphs to readable ASCII placeholders. ReportLab's embedded
#: TTF renderer cannot draw colour emoji glyphs, so we substitute text tags
#: that preserve the semantic meaning. Mirrors the upstream emojiMap.
EMOJI_SUBSTITUTIONS: dict[str, str] = {
    "\u23F3": "[WAIT]",      # ⏳
    "\u26A0\uFE0F": "[WARN]",  # ⚠️
    "\u26A0": "[WARN]",      # ⚠ (without FE0F variation selector)
    "\u26A1": "[RUN]",       # ⚡
    "\u2705": "[OK]",        # ✅
    "\u2728": "[NEW]",       # ✨
    "\u274C": "[FAIL]",      # ❌
    "\U0001F3AF": "[TARGET]",  # 🎯
    "\U0001F41B": "[BUG]",     # 🐛
    "\U0001F4A1": "[IDEA]",    # 💡
    "\U0001F4CA": "[DATA]",    # 📊
    "\U0001F4DD": "[NOTE]",    # 📝
    "\U0001F50D": "[SEARCH]",  # 🔍
    "\U0001F510": "[SEC]",     # 🔐
    "\U0001F527": "[TOOL]",    # 🔧
    "\U0001F680": "[START]",   # 🚀
}


_EMOJI_RE: re.Pattern[str] = re.compile(
    "|".join(re.escape(emo) for emo in sorted(EMOJI_SUBSTITUTIONS, key=len, reverse=True))
)


def substitute_emojis(text: str) -> str:
    """Replace every emoji glyph in ``text`` with its ``[TAG]`` placeholder.

    Mirrors PentAGI's ``replaceEmojis``. Multi-character emoji (e.g. ``⚠️``
    which is U+26A0 + U+FE0F) are matched as a single unit so the
    variation selector doesn't leak through.
    """
    if not text:
        return text
    return _EMOJI_RE.sub(lambda m: EMOJI_SUBSTITUTIONS[m.group(0)], text)


# ---------------------------------------------------------------------------
# Heading style table — font sizes from the PentAGI StyleSheet.
# ---------------------------------------------------------------------------

#: H1-H6 font sizes (points). Matches PentAGI's ``pdfStyles.h1`` … ``h6``.
HEADING_FONT_SIZES: dict[int, int] = {
    1: 16,
    2: 14,
    3: 13,
    4: 12,
    5: 11,
    6: 10,
}


# ---------------------------------------------------------------------------
# CJK text splitting — matches PentAGI's splitByCJK.
# ---------------------------------------------------------------------------

#: Regex matching any CJK unified ideographs or CJK punctuation / fullwidth
#: chars. Identical to the upstream ``CJK_RE`` (just ported to Python).
_CJK_RE: re.Pattern[str] = re.compile(
    r"[\u4E00-\u9FFF\u3400-\u4DBF\uF900-\uFAFF"
    r"\u3000-\u303F\uFF01-\uFF60\uFFE0-\uFFE6]+"
)


@dataclass(frozen=True)
class TextSegment:
    """A single CJK or non-CJK text run produced by :func:`split_by_cjk`."""

    is_cjk: bool
    text: str


def split_by_cjk(text: str) -> list[TextSegment]:
    """Split a string into alternating non-CJK / CJK segments.

    Mirrors PentAGI's ``splitByCJK``: each CJK run is emitted as a
    ``TextSegment(is_cjk=True, …)`` so the renderer can swap to the
    CJK font family for that segment. Non-CJK runs are emitted with
    ``is_cjk=False`` and render with the base Latin/Cyrillic font.

    The function always returns at least one segment (an empty input
    produces a single empty non-CJK segment, matching the upstream
    ``segments.length > 0 ? segments : [{isCJK: false, text}]`` guard).
    """
    if text is None:
        return [TextSegment(is_cjk=False, text="")]
    segments: list[TextSegment] = []
    last_index = 0
    for match in _CJK_RE.finditer(text):
        if match.start() > last_index:
            segments.append(
                TextSegment(is_cjk=False, text=text[last_index:match.start()])
            )
        segments.append(TextSegment(is_cjk=True, text=match.group(0)))
        last_index = match.end()
    if last_index < len(text):
        segments.append(TextSegment(is_cjk=False, text=text[last_index:]))
    return segments if segments else [TextSegment(is_cjk=False, text=text)]


# ---------------------------------------------------------------------------
# Markdown token model — produced by parse_markdown_tokens().
# ---------------------------------------------------------------------------


@dataclass
class InlineToken:
    """A single inline (paragraph-internal) styling token.

    Mirrors PentAGI's ``InlineToken``. Exactly one of ``code`` / ``bold`` /
    ``italic`` / ``link`` may be set; ``text`` is always populated.
    """

    text: str
    bold: bool = False
    italic: bool = False
    code: bool = False
    link: str | None = None


@dataclass
class ListItem:
    """A single list-item entry, possibly with nested sub-lists.

    ``inline_tokens`` is the item's own text content (after emoji
    substitution). ``children`` carries any nested block-level tokens
    — typically nested ``list`` Tokens for sub-bullets.
    """

    inline_tokens: list[InlineToken] = field(default_factory=list)
    children: list["Token"] = field(default_factory=list)


@dataclass
class Token:
    """A single block-level Markdown token.

    Mirrors PentAGI's ``ParsedContent`` (called ``Token`` here for
    brevity). One of ``code`` / ``heading`` / ``hr`` / ``list`` /
    ``paragraph`` / ``blockquote`` is set, identified by the ``type``
    field.
    """

    type: str
    # heading
    level: int = 0
    inline_tokens: list[InlineToken] = field(default_factory=list)
    # paragraph / code
    content: str = ""
    # list
    items: list[ListItem] = field(default_factory=list)
    ordered: bool = False
    # blockquote / nested-list children
    children: list["Token"] = field(default_factory=list)


# ---------------------------------------------------------------------------
# markdown-it-py → Token tree.
# ---------------------------------------------------------------------------


def _flatten_inline(token: Any) -> list[InlineToken]:
    """Convert a markdown-it-py inline token to a list of InlineToken.

    Walks the inline token's ``children`` list and produces a flat list
    of :class:`InlineToken` instances, applying emoji substitution at
    every text leaf (mirrors PentAGI's ``parseInlineTokens``). Delegates
    to :func:`_flatten_inline_with_state` for the actual state-machine
    walk that tracks ``*_open`` / ``*_close`` markers.
    """
    children = getattr(token, "children", None) or []
    return _flatten_inline_with_state(children)


def _flatten_inline_with_state(children: Sequence[Any]) -> list[InlineToken]:
    """Rebuild inline tokens by tracking ``*_open`` / ``*_close`` state."""
    out: list[InlineToken] = []
    bold = False
    italic = False
    code = False
    link_href: str | None = None

    for child in children:
        ttype = child.type
        if ttype == "text":
            out.append(
                InlineToken(
                    text=substitute_emojis(child.content or ""),
                    bold=bold,
                    italic=italic,
                    code=code,
                    link=link_href,
                )
            )
        elif ttype == "code_inline":
            out.append(
                InlineToken(
                    text=substitute_emojis(child.content or ""),
                    bold=bold,
                    italic=italic,
                    code=True,
                    link=link_href,
                )
            )
        elif ttype in ("softbreak", "hardbreak"):
            out.append(
                InlineToken(
                    text=" ",
                    bold=bold,
                    italic=italic,
                    code=code,
                    link=link_href,
                )
            )
        elif ttype == "strong_open":
            bold = True
        elif ttype == "strong_close":
            bold = False
        elif ttype == "em_open":
            italic = True
        elif ttype == "em_close":
            italic = False
        elif ttype == "link_open":
            # markdown-it-py exposes the href via .attrs (dict) or .attrGet.
            href = ""
            if hasattr(child, "attrGet"):
                href = child.attrGet("href") or ""
            elif hasattr(child, "attrs") and child.attrs:
                href = child.attrs.get("href", [""])[0] if child.attrs.get("href") else ""
            link_href = href or None
        elif ttype == "link_close":
            link_href = None
        else:
            content = getattr(child, "content", "") or ""
            if content:
                out.append(
                    InlineToken(
                        text=substitute_emojis(content),
                        bold=bold,
                        italic=italic,
                        code=code,
                        link=link_href,
                    )
                )
    return out


def parse_markdown_tokens(text: str) -> list[Token]:
    """Parse Markdown text into a flat list of block-level Tokens.

    Uses ``markdown-it-py`` (lazy-imported) under the hood. Supported
    block types: ``heading``, ``paragraph``, ``code`` (fenced &
    indented), ``hr``, ``bullet_list`` / ``ordered_list``,
    ``blockquote``. All other block types are silently dropped (matching
    PentAGI's ``default:`` case which only pushes paragraph tokens for
    tokens with a ``text`` attribute).
    """
    if not text:
        return []
    # Lazy import so the module loads even if markdown-it-py is missing.
    try:
        from markdown_it import MarkdownIt
    except ImportError as exc:  # pragma: no cover — dependency is required
        raise RuntimeError(
            "markdown-it-py is required for parse_markdown_tokens "
            "(install: pip install markdown-it-py)"
        ) from exc

    md = MarkdownIt("commonmark", {"breaks": False, "html": False})
    md.enable("table")
    tokens = md.parse(text)
    return _convert_mdit_tokens(tokens)


def _parse_list_items(tokens: Sequence[Any], ordered: bool) -> list[ListItem]:
    """Parse the inner tokens of a list into a list of ListItem objects.

    Walks the token list, identifying ``list_item_open`` … ``list_item_close``
    pairs. For each item:

    * ``inline`` tokens become the item's ``inline_tokens``.
    * Nested ``bullet_list_open`` / ``ordered_list_open`` blocks become
      nested ``Token(type="list")`` children of the item.
    * ``paragraph_open`` / ``paragraph_close`` markers are skipped (the
      inner ``inline`` token carries the actual content).
    """
    items: list[ListItem] = []
    i = 0
    n = len(tokens)
    while i < n:
        if tokens[i].type == "list_item_open":
            # Find the matching list_item_close at the same depth.
            depth = 1
            j = i + 1
            inner: list[Any] = []
            while j < n and depth > 0:
                if tokens[j].type == "list_item_open":
                    depth += 1
                elif tokens[j].type == "list_item_close":
                    depth -= 1
                    if depth == 0:
                        break
                inner.append(tokens[j])
                j += 1
            item_inline: list[InlineToken] = []
            item_children: list[Token] = []
            k = 0
            m = len(inner)
            while k < m:
                if inner[k].type == "inline":
                    item_inline.extend(
                        _flatten_inline_with_state(
                            getattr(inner[k], "children", []) or []
                        )
                    )
                    k += 1
                    continue
                if inner[k].type in ("bullet_list_open", "ordered_list_open"):
                    nested_ordered = inner[k].type == "ordered_list_open"
                    close_type = f"{inner[k].type[:-5]}_close"
                    # Slice the nested list's tokens.
                    p = k + 1
                    nd = 1
                    nested_inner: list[Any] = []
                    while p < m and nd > 0:
                        if inner[p].type == inner[k].type:
                            nd += 1
                        elif inner[p].type == close_type:
                            nd -= 1
                            if nd == 0:
                                break
                        nested_inner.append(inner[p])
                        p += 1
                    item_children.append(
                        Token(
                            type="list",
                            items=_parse_list_items(nested_inner, nested_ordered),
                            ordered=nested_ordered,
                        )
                    )
                    k = p + 1
                    continue
                # paragraph_open / paragraph_close / softbreak etc. — skip.
                k += 1
            items.append(
                ListItem(inline_tokens=item_inline, children=item_children)
            )
            i = j + 1
            continue
        i += 1
    return items


def _convert_mdit_tokens(tokens: Sequence[Any]) -> list[Token]:
    """Walk the markdown-it-py token list and produce flat Token objects."""
    out: list[Token] = []
    i = 0
    n = len(tokens)
    while i < n:
        tok = tokens[i]
        ttype = tok.type

        if ttype == "heading_open":
            level = int(tok.tag[1:]) if tok.tag and tok.tag.startswith("h") else 1
            # The next token is the inline content; the one after is _close.
            if i + 1 < n and tokens[i + 1].type == "inline":
                inline = tokens[i + 1]
                out.append(
                    Token(
                        type="heading",
                        level=level,
                        inline_tokens=_flatten_inline_with_state(
                            getattr(inline, "children", []) or []
                        ),
                    )
                )
            i += 3  # skip heading_open, inline, heading_close
            continue

        if ttype == "paragraph_open":
            if i + 1 < n and tokens[i + 1].type == "inline":
                inline = tokens[i + 1]
                out.append(
                    Token(
                        type="paragraph",
                        inline_tokens=_flatten_inline_with_state(
                            getattr(inline, "children", []) or []
                        ),
                    )
                )
            i += 3
            continue

        if ttype == "fence" or ttype == "code_block":
            out.append(
                Token(
                    type="code",
                    content=substitute_emojis(tok.content or ""),
                )
            )
            i += 1
            continue

        if ttype == "hr":
            out.append(Token(type="hr"))
            i += 1
            continue

        if ttype in ("bullet_list_open", "ordered_list_open"):
            ordered = ttype == "ordered_list_open"
            # bullet_list_open → bullet_list_close (drop the 5-char "_open"
            # suffix, not 4 chars "_ope" — common off-by-one source).
            close_type = f"{ttype[:-5]}_close"
            # Slice the token list to just this list's contents (matching
            # open / close pair), then recursively parse the inner tokens
            # into ListItem objects. This handles nested lists naturally
            # because the recursive call walks each list_item_open and
            # any nested *_list_open it contains.
            j = i + 1
            depth = 1
            inner_tokens: list[Any] = []
            while j < n and depth > 0:
                if tokens[j].type == ttype:
                    depth += 1
                elif tokens[j].type == close_type:
                    depth -= 1
                    if depth == 0:
                        break
                inner_tokens.append(tokens[j])
                j += 1
            items = _parse_list_items(inner_tokens, ordered)
            out.append(Token(type="list", items=items, ordered=ordered))
            i = j + 1
            continue

        if ttype == "blockquote_open":
            # Collect tokens until blockquote_close, then recurse.
            j = i + 1
            depth = 1
            inner: list[Any] = []
            while j < n and depth > 0:
                if tokens[j].type == "blockquote_open":
                    depth += 1
                elif tokens[j].type == "blockquote_close":
                    depth -= 1
                    if depth == 0:
                        break
                inner.append(tokens[j])
                j += 1
            out.append(
                Token(type="blockquote", children=_convert_mdit_tokens(inner))
            )
            i = j + 1
            continue

        if ttype == "inline":
            # Stand-alone inline token (rare in commonmark output but
            # possible if the parser is configured differently). Treat
            # as a paragraph.
            out.append(
                Token(
                    type="paragraph",
                    inline_tokens=_flatten_inline_with_state(
                        getattr(tok, "children", []) or []
                    ),
                )
            )
            i += 1
            continue

        # Everything else (html_block, footnote, etc.) is dropped —
        # matches PentAGI's default case.
        i += 1
    return out


# ---------------------------------------------------------------------------
# ReportLab rendering.
# ---------------------------------------------------------------------------

#: Colours (hex strings) lifted from PentAGI's pdfStyles for visual parity.
_COLOR_H1 = "#0F172A"
_COLOR_H2 = "#1E293B"
_COLOR_H3 = "#334155"
_COLOR_H4 = "#475569"
_COLOR_H5 = "#64748B"
_COLOR_H6 = "#94A3B8"
_COLOR_PARA = "#475569"
_COLOR_CODE_INLINE = "#DC2626"
_COLOR_LINK = "#2563EB"
_COLOR_HR = "#CBD5E1"
_COLOR_CODE_BG = "#1E293B"
_COLOR_CODE_FG = "#E2E8F0"
_COLOR_LIST_BULLET = "#64748B"
_COLOR_LIST_CONTENT = "#334155"

_HEADING_COLORS: dict[int, str] = {
    1: _COLOR_H1,
    2: _COLOR_H2,
    3: _COLOR_H3,
    4: _COLOR_H4,
    5: _COLOR_H5,
    6: _COLOR_H6,
}


# ---------------------------------------------------------------------------
# XML/HTML escaping for ReportLab Paragraph mini-HTML.
# ---------------------------------------------------------------------------

_XML_ESCAPE_TABLE = str.maketrans(
    {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
    }
)


def _xml_escape(text: str) -> str:
    """Escape ``&``, ``<``, ``>`` for ReportLab Paragraph mini-HTML."""
    return text.translate(_XML_ESCAPE_TABLE)


def _render_inline_to_xml(tokens: Iterable[InlineToken]) -> str:
    """Render inline tokens to ReportLab mini-HTML.

    Each CJK segment is wrapped in ``<font face="NotoSansSC">…</font>``;
    italic is dropped for CJK segments (CJK fonts have no italic glyph).
    Bold/italic/code/link markers wrap the entire run.

    Anchor-only links (``href="#anchor"``) are rendered as styled text
    without an active ``<link>`` tag — ReportLab requires named
    destinations to resolve in-document anchors, and the TOC layout is
    still readable as a list of section titles. External links
    (``http://…``) remain active.
    """
    parts: list[str] = []
    for tok in tokens:
        text = _xml_escape(tok.text)
        segments = split_by_cjk(text)
        rendered_segments: list[str] = []
        for seg in segments:
            seg_text = seg.text
            if not seg_text:
                continue
            # Anchor-only links → styled text, no <link> tag (avoids
            # ReportLab's "format not resolved" error for in-doc anchors).
            is_anchor_link = bool(tok.link and tok.link.startswith("#"))
            if seg.is_cjk:
                # CJK runs use the SC font family. Italic is dropped
                # (no CJK italic variant available).
                seg_html = f'<font face="NotoSansSC">{seg_text}</font>'
                if tok.bold:
                    seg_html = f"<b>{seg_html}</b>"
                if tok.code:
                    seg_html = f'<font color="{_COLOR_CODE_INLINE}">{seg_html}</font>'
                if tok.link and not is_anchor_link:
                    seg_html = (
                        f'<link href="{_xml_escape(tok.link)}" '
                        f'color="{_COLOR_LINK}"><u>{seg_html}</u></link>'
                    )
                elif tok.link and is_anchor_link:
                    seg_html = f'<font color="{_COLOR_LINK}"><u>{seg_html}</u></font>'
                rendered_segments.append(seg_html)
            else:
                seg_html = seg_text
                if tok.code:
                    seg_html = (
                        f'<font face="NotoSansMono" color="{_COLOR_CODE_INLINE}">'
                        f"<b>{seg_html}</b></font>"
                    )
                else:
                    if tok.bold:
                        seg_html = f"<b>{seg_html}</b>"
                    if tok.italic:
                        seg_html = f"<i>{seg_html}</i>"
                    if tok.link and not is_anchor_link:
                        seg_html = (
                            f'<link href="{_xml_escape(tok.link)}" '
                            f'color="{_COLOR_LINK}"><u>{seg_html}</u></link>'
                        )
                    elif tok.link and is_anchor_link:
                        seg_html = f'<font color="{_COLOR_LINK}"><u>{seg_html}</u></font>'
                rendered_segments.append(seg_html)
        parts.append("".join(rendered_segments))
    return "".join(parts)


# ---------------------------------------------------------------------------
# Font registration (lazy — only called when a PDF is rendered).
# ---------------------------------------------------------------------------

_FONTS_REGISTERED: bool = False


def _register_fonts() -> None:
    """Register the three font families with ReportLab's pdfmetrics.

    Idempotent — sets a module-level flag so subsequent calls are no-ops.
    Missing font files are logged and fall back to the built-in Helvetica
    family so rendering still produces *a* PDF (just without CJK coverage).
    """
    global _FONTS_REGISTERED
    if _FONTS_REGISTERED:
        return
    try:
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.pdfbase.pdfmetrics import registerFontFamily
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "reportlab is required for PDF rendering "
            "(install: pip install reportlab)"
        ) from exc

    for family, variants in FONT_SEARCH_PATHS.items():
        # Register each variant TTF. The regular variant is registered
        # under the *bare* family name (e.g. "NotoSans") so styles can
        # set ``fontName="NotoSans"`` and ReportLab's ``ps2tt`` resolver
        # can still look up the family → (bold, italic) tuple via the
        # ``registerFontFamily`` call below.
        registered: dict[str, str] = {}
        for variant, paths in variants.items():
            path = _first_existing(paths)
            if path is None:
                logger.warning(
                    "Font %s/%s: no candidate path exists (%s); "
                    "falling back to Helvetica.",
                    family,
                    variant,
                    paths[0] if paths else "<empty>",
                )
                continue
            # Bare family name for the regular variant; explicit suffix
            # for bold / italic / bolditalic so <b>/<i> in Paragraph
            # markup auto-resolves to the right TTF. Variant name is
            # capitalised as a whole word (BoldItalic, not Bolditalic).
            if variant == "regular":
                font_name = family
            else:
                suffix = {
                    "bold": "Bold",
                    "italic": "Italic",
                    "bolditalic": "BoldItalic",
                }.get(variant, variant.capitalize())
                font_name = f"{family}-{suffix}"
            try:
                pdfmetrics.registerFont(TTFont(font_name, path))
                registered[variant] = font_name
            except Exception as exc:
                logger.warning(
                    "Failed to register font %s/%s from %s: %s",
                    family,
                    variant,
                    path,
                    exc,
                )

        # Register the family mapping so <b>/<i> auto-select bold/italic
        # variants inside Paragraph markup. Missing variants fall back
        # to the regular variant so rendering still produces a valid PDF.
        normal = registered.get("regular", "Helvetica")
        bold = registered.get("bold", normal)
        italic = registered.get("italic", normal)
        bolditalic = registered.get("bolditalic", bold)
        registerFontFamily(
            family,
            normal=normal,
            bold=bold,
            italic=italic,
            boldItalic=bolditalic,
        )

    _FONTS_REGISTERED = True


# ---------------------------------------------------------------------------
# Paragraph styles.
# ---------------------------------------------------------------------------

_STYLE_CACHE: dict[str, Any] = {}


def _get_style(name: str) -> Any:
    """Build (and cache) a ReportLab ParagraphStyle by name."""
    if name in _STYLE_CACHE:
        return _STYLE_CACHE[name]
    from reportlab.lib.styles import ParagraphStyle

    base = ParagraphStyle(
        name=name,
        fontName="NotoSans",
        fontSize=10,
        leading=14,
        textColor=_COLOR_PARA,
        spaceBefore=4,
        spaceAfter=6,
    )
    if name == "Body":
        pass
    elif name == "Code":
        base.fontName = "NotoSansMono"
        base.fontSize = 9
        base.leading = 12
        base.textColor = _COLOR_CODE_FG
        base.backColor = _COLOR_CODE_BG
        base.spaceBefore = 4
        base.spaceAfter = 8
        base.leftIndent = 6
        base.rightIndent = 6
        # borderPadding / borderWidth / borderColor give the light-gray
        # background a visible box (matches PentAGI's codeBlock style).
        base.borderPadding = 6
    elif name.startswith("H"):
        level = int(name[1:])
        size = HEADING_FONT_SIZES.get(level, 10)
        base.fontSize = size
        base.leading = int(size * 1.2)
        base.fontName = "NotoSans-Bold"
        base.textColor = _HEADING_COLORS.get(level, _COLOR_H6)
        base.spaceBefore = 12 if level <= 2 else 8
        base.spaceAfter = 6 if level <= 2 else 4
    elif name == "ListItem":
        base.fontSize = 10
        base.leading = 14
        base.textColor = _COLOR_LIST_CONTENT
        base.spaceBefore = 0
        base.spaceAfter = 2
    elif name == "Blockquote":
        base.leftIndent = 16
        base.rightIndent = 8
        base.textColor = _COLOR_H5
        base.fontName = "NotoSans"
    _STYLE_CACHE[name] = base
    return base


# ---------------------------------------------------------------------------
# Token → ReportLab flowable conversion.
# ---------------------------------------------------------------------------


def _tokens_to_flowables(
    tokens: Sequence[Token],
    *,
    first_h1_is_cover: bool = True,
) -> list[Any]:
    """Convert parsed Tokens into a list of ReportLab flowables.

    The ``first_h1_is_cover`` flag controls the page-break behaviour:

    * ``True``  — the first ``H1`` token starts the cover page; a
      :class:`PageBreak` is inserted after it and after the first ``HR``
      (which marks the TOC/main-content boundary). This implements the
      page-break rule: *only between cover and TOC, and between TOC and
      main content*.
    * ``False`` — no automatic page breaks are inserted.
    """
    from reportlab.platypus import (
        HRFlowable,
        ListFlowable,
        ListItem as RLListItem,
        PageBreak,
        Paragraph,
        Preformatted,
        Spacer,
    )

    def _render_list_token(list_tok: Token, indent: int = 18) -> ListFlowable:
        """Render a Token(type="list") recursively as a ListFlowable.

        Nested list children of each item are rendered as nested
        ListFlowables inside the parent's :class:`RLListItem`. The
        ``indent`` parameter controls the left indentation of the bullet
        column so nested lists visually nest.
        """
        rl_items: list[RLListItem] = []
        for item in list_tok.items:
            xml = _render_inline_to_xml(item.inline_tokens)
            if not xml.strip():
                xml = "&nbsp;"
            inner_flowables: list[Any] = [Paragraph(xml, _get_style("ListItem"))]
            # Render any nested lists as child ListFlowables.
            for child in item.children:
                if child.type == "list":
                    inner_flowables.append(_render_list_token(child, indent=indent + 14))
                else:
                    inner_flowables.extend(
                        _tokens_to_flowables([child], first_h1_is_cover=False)
                    )
            rl_items.append(
                RLListItem(
                    inner_flowables,
                    leftIndent=indent,
                    value=None,
                )
            )
        return ListFlowable(
            rl_items,
            bulletType="1" if list_tok.ordered else "bullet",
            start="1" if list_tok.ordered else None,
            bulletColor=_COLOR_LIST_BULLET,
            bulletFontName="NotoSans",
            bulletFontSize=9,
            leftIndent=indent,
            spaceBefore=4,
            spaceAfter=8,
        )

    flowables: list[Any] = []
    seen_first_h1 = False
    seen_first_hr_after_h1 = False

    for tok in tokens:
        ttype = tok.type

        if ttype == "heading":
            level = max(1, min(6, tok.level or 1))
            style = _get_style(f"H{level}")
            xml = _render_inline_to_xml(tok.inline_tokens)
            if not xml.strip():
                continue
            # Cover / TOC / main page-break logic.
            if level == 1 and first_h1_is_cover and not seen_first_h1:
                seen_first_h1 = True
                flowables.append(Paragraph(xml, style))
                flowables.append(PageBreak())
                continue
            flowables.append(Paragraph(xml, style))
            continue

        if ttype == "paragraph":
            xml = _render_inline_to_xml(tok.inline_tokens)
            if not xml.strip():
                continue
            flowables.append(Paragraph(xml, _get_style("Body")))
            continue

        if ttype == "code":
            if not tok.content.strip():
                continue
            # Use Preformatted so line breaks and indentation survive.
            # The Code style sets the background / monospace font.
            flowables.append(Preformatted(tok.content, _get_style("Code")))
            continue

        if ttype == "hr":
            flowables.append(
                HRFlowable(
                    width="100%",
                    thickness=0.5,
                    color=_COLOR_HR,
                    spaceBefore=12,
                    spaceAfter=12,
                )
            )
            if first_h1_is_cover and seen_first_h1 and not seen_first_hr_after_h1:
                seen_first_hr_after_h1 = True
                flowables.append(PageBreak())
            continue

        if ttype == "list":
            if not tok.items:
                continue
            flowables.append(_render_list_token(tok))
            continue

        if ttype == "blockquote":
            # Render children indented; recurse without page breaks.
            inner_flowables = _tokens_to_flowables(
                tok.children, first_h1_is_cover=False
            )
            for f in inner_flowables:
                flowables.append(f)
            continue

        # Unknown token — skip silently (matches PentAGI's default case).
        continue

    return flowables


# ---------------------------------------------------------------------------
# Public entry points.
# ---------------------------------------------------------------------------


def render_to_pdf_bytes(markdown: str) -> bytes:
    """Render Markdown text to a PDF document and return it as ``bytes``.

    Uses ReportLab's :class:`BaseDocTemplate` with A4 pages and 40pt
    margins (matching PentAGI's ``pdfStyles.page.padding``). Hyphenation
    is disabled by setting ``splitLongWords=False`` on the body style —
    long CJK / Cyrillic words stay intact and wrap only on whitespace.
    """
    if not isinstance(markdown, str):
        raise TypeError("markdown must be a string")
    _register_fonts()

    from io import BytesIO

    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate

    tokens = parse_markdown_tokens(markdown)
    flowables = _tokens_to_flowables(tokens, first_h1_is_cover=True)

    buf = BytesIO()
    doc = BaseDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=40,
        rightMargin=40,
        topMargin=40,
        bottomMargin=40,
        title="Elengenix Report",
        author="Elengenix",
    )
    frame = Frame(
        doc.leftMargin,
        doc.bottomMargin,
        doc.width,
        doc.height,
        id="normal",
        leftPadding=0,
        rightPadding=0,
        topPadding=0,
        bottomPadding=0,
    )
    doc.addPageTemplates([PageTemplate(id="main", frames=[frame])])
    doc.build(flowables)
    return buf.getvalue()


def render_to_pdf(markdown: str, output_path: str) -> str:
    """Render Markdown text to a PDF file at ``output_path``.

    Returns the absolute path to the saved PDF. Parent directories are
    created if missing. The function is synchronous because ReportLab
    is itself synchronous; for async callers, wrap with
    ``asyncio.to_thread(render_to_pdf, …)``.
    """
    if not output_path:
        raise ValueError("output_path is required")
    data = render_to_pdf_bytes(markdown)
    abs_path = os.path.abspath(output_path)
    parent = os.path.dirname(abs_path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    with open(abs_path, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %d-byte PDF to %s", len(data), abs_path)
    return abs_path


__all__ = [
    "EMOJI_SUBSTITUTIONS",
    "HEADING_FONT_SIZES",
    "FONT_SEARCH_PATHS",
    "TextSegment",
    "InlineToken",
    "Token",
    "substitute_emojis",
    "split_by_cjk",
    "parse_markdown_tokens",
    "render_to_pdf",
    "render_to_pdf_bytes",
]
