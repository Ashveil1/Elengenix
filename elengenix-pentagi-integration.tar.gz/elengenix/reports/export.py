"""elengenix/reports/export.py — multi-format report exporter.

This module is the top-level entry point for the report pipeline. Given a
flow ID, it:

1. Resolves the flow + its tasks + subtasks via the
   :class:`elengenix.flows.manager.FlowManager` (or any duck-typed
   provider with the same method surface).
2. Assembles the canonical Markdown report via
   :func:`elengenix.reports.markdown.generate_report_markdown`.
3. Renders the Markdown to the requested output format
   (``pdf`` / ``markdown`` / ``html`` / ``json``).

Public API
----------
* :func:`export_report`        — async, returns ``bytes`` for the format.
* :func:`generate_filename`    — async, returns a slug-prefixed filename.
* :func:`render_html`          — sync helper: Markdown → HTML + CSS.
* :func:`render_json_payload`  — sync helper: structured JSON dict.

The HTML renderer uses ``markdown-it-py`` with the ``html`` output plus
``pygments`` for syntax highlighting. CSS is embedded inline so the
resulting HTML file is fully self-contained (no external stylesheets).
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import unicodedata
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Protocol, runtime_checkable

logger = logging.getLogger("elengenix.reports.export")


# ---------------------------------------------------------------------------
# Format → file extension lookup.
# ---------------------------------------------------------------------------

_FORMAT_EXTENSIONS: dict[str, str] = {
    "pdf": "pdf",
    "markdown": "md",
    "md": "md",
    "html": "html",
    "htm": "html",
    "json": "json",
}

#: Set of supported export formats (canonical, lowercase).
SUPPORTED_FORMATS: frozenset[str] = frozenset(
    {"pdf", "markdown", "html", "json"}
)


# ---------------------------------------------------------------------------
# Flow-provider Protocol — duck-typed subset of FlowManager.
# ---------------------------------------------------------------------------


@runtime_checkable
class FlowDataProvider(Protocol):
    """Subset of :class:`elengenix.flows.manager.FlowManager` we consume.

    Implementations must expose two async methods:

    * ``get_flow(flow_id)`` — return a Flow-like object with ``id``,
      ``status``, ``title``.
    * ``list_tasks(flow_id)`` — return an iterable of Task-like objects
      (each with ``id``, ``status``, ``title``, ``input``, ``result``).
    * ``list_subtasks(task_id)`` — return an iterable of Subtask-like
      objects (each with ``id``, ``status``, ``title``, ``description``,
      ``result``, ``task_id``).
    """

    async def get_flow(self, flow_id: int) -> Any: ...

    async def list_tasks(self, flow_id: int) -> Any: ...

    async def list_subtasks(self, task_id: int) -> Any: ...


# ---------------------------------------------------------------------------
# Filename generation — matches PentAGI's generateFileName + the spec.
# ---------------------------------------------------------------------------


_NON_FILENAME_CHARS_RE = re.compile(r"[^\w\s.-]", re.UNICODE)
_WHITESPACE_RE = re.compile(r"[\s\u2000-\u200B]+")


def _slugify_title(title: str, max_length: int = 150) -> str:
    """Slugify a flow title for use in a filename.

    Mirrors PentAGI's ``generateFileName``: replace any non-word char
    (except spaces, dots, hyphens) with ``_``, collapse whitespace to
    ``_``, lowercase, trim, then truncate to ``max_length`` and strip
    trailing underscores.
    """
    if not title:
        return "untitled"
    s = _NON_FILENAME_CHARS_RE.sub("_", title)
    s = _WHITESPACE_RE.sub("_", s)
    s = s.lower()
    if len(s) > max_length:
        s = s[:max_length]
    s = s.rstrip("_")
    return s or "untitled"


def _format_timestamp(dt: datetime | None = None) -> str:
    """Return a ``YYYYMMDDHHMMSS`` timestamp in UTC."""
    if dt is None:
        dt = datetime.now(timezone.utc)
    return dt.strftime("%Y%m%d%H%M%S")


async def generate_filename(
    flow_id: int,
    title: str,
    format: str,
) -> str:
    """Build a filename for an exported report.

    Pattern (from the task spec):

    .. code-block:: text

        report_flow_{flow_id}_{slugified_title[:150]}_{YYYYMMDDHHMMSS}.{ext}

    The slug is built via :func:`_slugify_title`; the extension comes
    from :data:`_FORMAT_EXTENSIONS`. Unknown formats fall back to
    ``txt``.
    """
    fmt = (format or "").lower().strip()
    ext = _FORMAT_EXTENSIONS.get(fmt, "txt")
    slug = _slugify_title(title, max_length=150)
    ts = _format_timestamp()
    return f"report_flow_{flow_id}_{slug}_{ts}.{ext}"


# ---------------------------------------------------------------------------
# Default flow-data provider — lazily constructs a FlowManager.
# ---------------------------------------------------------------------------


async def _default_provider() -> FlowDataProvider:
    """Build a default :class:`FlowManager` instance.

    Lazy-imports :mod:`elengenix.flows.manager` so this module can be
    imported even if the heavier flows stack (aiosqlite, etc.) isn't
    installed yet.
    """
    from elengenix.flows.manager import FlowManager

    return FlowManager()


# ---------------------------------------------------------------------------
# HTML rendering — Markdown → self-contained HTML + CSS.
# ---------------------------------------------------------------------------


#: Default CSS for the HTML export — mirrors the PentAGI pdfStyles palette.
_HTML_CSS: str = """
:root {
    --color-h1: #0f172a;
    --color-h2: #1e293b;
    --color-h3: #334155;
    --color-h4: #475569;
    --color-h5: #64748b;
    --color-h6: #94a3b8;
    --color-body: #475569;
    --color-link: #2563eb;
    --color-code-bg: #1e293b;
    --color-code-fg: #e2e8f0;
    --color-inline-code: #dc2626;
    --color-hr: #cbd5e1;
}
html, body {
    font-family: 'Noto Sans', 'Liberation Sans', 'Helvetica', sans-serif;
    font-size: 14px;
    line-height: 1.6;
    color: var(--color-body);
    max-width: 900px;
    margin: 2rem auto;
    padding: 0 1rem;
}
h1 { color: var(--color-h1); font-size: 22pt; margin: 1em 0 0.5em; }
h2 { color: var(--color-h2); font-size: 18pt; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; }
h3 { color: var(--color-h3); font-size: 16pt; }
h4 { color: var(--color-h4); font-size: 14pt; }
h5 { color: var(--color-h5); font-size: 12pt; }
h6 { color: var(--color-h6); font-size: 11pt; }
p  { margin: 0 0 0.8em; text-align: justify; }
a  { color: var(--color-link); text-decoration: underline; }
code {
    font-family: 'Noto Sans Mono', 'Liberation Mono', monospace;
    color: var(--color-inline-code);
    font-weight: bold;
    background: #f1f5f9;
    padding: 1px 4px;
    border-radius: 3px;
    font-size: 0.9em;
}
pre {
    background: var(--color-code-bg);
    color: var(--color-code-fg);
    padding: 12px 14px;
    border-radius: 4px;
    overflow-x: auto;
    line-height: 1.4;
    font-size: 0.85em;
}
pre code {
    background: transparent;
    color: inherit;
    font-weight: normal;
    padding: 0;
    border-radius: 0;
}
blockquote {
    border-left: 4px solid var(--color-h6);
    margin: 0.8em 0;
    padding: 0.2em 0 0.2em 1em;
    color: var(--color-h5);
}
hr {
    border: none;
    border-top: 1px solid var(--color-hr);
    margin: 1.5em 0;
}
ul, ol { padding-left: 1.6em; margin: 0.4em 0 0.8em; }
li { margin: 0.2em 0; }
table {
    border-collapse: collapse;
    width: 100%;
    margin: 1em 0;
}
th, td {
    border: 1px solid #cbd5e1;
    padding: 6px 10px;
    text-align: left;
}
th { background: #f1f5f9; font-weight: bold; }
"""


def render_html(markdown: str, *, include_css: bool = True) -> str:
    """Render Markdown text to a self-contained HTML document.

    Uses ``markdown-it-py`` with the ``html`` output plus ``pygments``
    for syntax highlighting (if installed; falls back to plain
    ``<code>`` if not). CSS is embedded inline so the HTML file is
    fully portable.
    """
    try:
        from markdown_it import MarkdownIt
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "markdown-it-py is required for HTML export "
            "(install: pip install markdown-it-py)"
        ) from exc

    # Configure markdown-it-py with commonmark + tables + fenced code
    # highlighting via pygments (if available).
    try:
        from pygments.formatters import HtmlFormatter  # type: ignore

        pygments_available = True
    except ImportError:
        pygments_available = False

    md = MarkdownIt(
        "commonmark",
        {
            "breaks": False,
            "html": False,
            "highlight": _make_pygments_highlighter() if pygments_available else None,
        },
    )
    md.enable("table")
    md.enable("strikethrough")

    body_html = md.render(markdown or "")

    # Inline pygments CSS (only the token colours, not the body styles).
    pygments_css = ""
    if pygments_available:
        try:
            pygments_css = HtmlFormatter(style="monokai").get_style_defs(".codehilite")
        except Exception:  # pragma: no cover
            pygments_css = ""

    css = _HTML_CSS
    if pygments_css:
        css = css + "\n" + pygments_css

    if not include_css:
        return body_html

    return (
        "<!DOCTYPE html>\n"
        '<html lang="en">\n'
        "<head>\n"
        '<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
        "<title>Elengenix Report</title>\n"
        f"<style>\n{css}\n</style>\n"
        "</head>\n"
        "<body>\n"
        f"{body_html}\n"
        "</body>\n"
        "</html>\n"
    )


def _make_pygments_highlighter():
    """Build a markdown-it-py highlight callback backed by pygments."""
    from pygments import highlight  # type: ignore
    from pygments.formatters import HtmlFormatter  # type: ignore
    from pygments.lexers import get_lexer_by_name, guess_lexer  # type: ignore
    from pygments.util import ClassNotFound  # type: ignore

    formatter = HtmlFormatter(style="monokai", nowrap=False, classprefix="")

    def _highlight(src: str, lang: str, attrs: Any) -> str:
        if lang:
            try:
                lexer = get_lexer_by_name(lang)
            except ClassNotFound:
                lexer = None
        else:
            lexer = None
            try:
                lexer = guess_lexer(src)
            except Exception:
                lexer = None
        if lexer is None:
            # No lexer — return plain escaped <pre><code>.
            return (
                f'<pre class="codehilite"><code>'
                f"{src.replace('<', '&lt;').replace('>', '&gt;')}"
                f"</code></pre>"
            )
        return highlight(src, lexer, formatter)

    return _highlight


# ---------------------------------------------------------------------------
# JSON rendering — structured payload.
# ---------------------------------------------------------------------------


def _to_plain(obj: Any) -> Any:
    """Recursively convert a Pydantic model / dataclass / enum to plain JSON."""
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    # Enum (str or otherwise) → its value.
    if hasattr(obj, "value") and not isinstance(obj, type):
        try:
            from enum import Enum

            if isinstance(obj, Enum):
                return obj.value
        except ImportError:
            pass
    # Pydantic v2 model.
    if hasattr(obj, "model_dump"):
        try:
            return _to_plain(obj.model_dump(mode="json"))
        except Exception:
            pass
    # Pydantic v1 model.
    if hasattr(obj, "dict") and callable(getattr(obj, "dict", None)):
        try:
            return _to_plain(obj.dict())
        except Exception:
            pass
    # dataclass.
    if hasattr(obj, "__dataclass_fields__"):
        return {
            k: _to_plain(getattr(obj, k))
            for k in obj.__dataclass_fields__
        }
    if isinstance(obj, dict):
        return {str(k): _to_plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_to_plain(v) for v in obj]
    # Fallback — let json handle it (or fail).
    return str(obj)


def render_json_payload(
    flow: Any,
    tasks: Iterable[Any],
    subtasks: Iterable[Any],
    *,
    findings: Iterable[Mapping[str, Any]] | None = None,
    cvss_scores: Iterable[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build the structured JSON payload for an exported report.

    The payload schema:

    .. code-block:: json

        {
          "flow":       { ... },
          "tasks":      [ { ..., "subtasks": [...] }, ... ],
          "findings":   [ ... ],
          "cvss_scores":[ ... ],
          "generated_at": "2024-..."
        }

    Subtasks are nested under their parent task (matched by ``task_id``).
    """
    task_list = list(tasks) if tasks else []
    subtask_list = list(subtasks) if subtasks else []

    # Group subtasks by task_id for nesting.
    subtasks_by_task: dict[int, list[Any]] = {}
    for st in subtask_list:
        st_task_id = getattr(st, "task_id", None)
        if st_task_id is None:
            continue
        try:
            key = int(st_task_id)
        except (TypeError, ValueError):
            continue
        subtasks_by_task.setdefault(key, []).append(_to_plain(st))

    tasks_json: list[dict[str, Any]] = []
    for task in task_list:
        task_dict = _to_plain(task)
        if not isinstance(task_dict, dict):
            task_dict = {"raw": task_dict}
        task_id = task_dict.get("id")
        if isinstance(task_id, int):
            task_dict["subtasks"] = subtasks_by_task.get(task_id, [])
        else:
            task_dict["subtasks"] = []
        tasks_json.append(task_dict)

    return {
        "flow": _to_plain(flow),
        "tasks": tasks_json,
        "findings": [_to_plain(f) for f in (findings or [])],
        "cvss_scores": [_to_plain(c) for c in (cvss_scores or [])],
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Public async entry point.
# ---------------------------------------------------------------------------


async def export_report(
    flow_id: int,
    format: str = "pdf",
    *,
    provider: FlowDataProvider | None = None,
    output_path: str | None = None,
) -> bytes:
    """Export a flow report as ``bytes`` in the requested format.

    Parameters
    ----------
    flow_id
        The flow to export.
    format
        One of ``"pdf"``, ``"markdown"``, ``"html"``, ``"json"``.
        Unknown formats raise :class:`ValueError`.
    provider
        Optional :class:`FlowDataProvider`. If omitted, a default
        :class:`FlowManager` is constructed lazily.
    output_path
        If supplied, the bytes are also written to this path.

    Returns
    -------
    bytes
        The raw bytes of the exported report.

    Notes
    -----
    The flow / tasks / subtasks are fetched concurrently via
    :func:`asyncio.gather`. The Markdown assembly and PDF render are
    CPU-bound and run in the calling thread (ReportLab is not
    thread-safe enough to use :func:`asyncio.to_thread` reliably for a
    single doc, and the latency is small).
    """
    fmt = (format or "").lower().strip()
    if fmt not in SUPPORTED_FORMATS:
        raise ValueError(
            f"Unsupported export format {format!r}; "
            f"supported: {sorted(SUPPORTED_FORMATS)}"
        )

    if provider is None:
        provider = await _default_provider()

    # Fetch flow + top-level tasks concurrently.
    flow, tasks = await asyncio.gather(
        provider.get_flow(flow_id),
        provider.list_tasks(flow_id),
    )
    if flow is None:
        raise ValueError(f"Flow {flow_id} not found")

    tasks_list = list(tasks) if tasks else []
    # Fetch subtasks for each task concurrently.
    subtasks_per_task = await asyncio.gather(
        *(provider.list_subtasks(int(t.id)) for t in tasks_list),
        return_exceptions=False,
    ) if tasks_list else []

    all_subtasks: list[Any] = []
    for subtasks in subtasks_per_task:
        if subtasks:
            all_subtasks.extend(subtasks)

    # Dispatch to the format-specific renderer.
    if fmt == "json":
        return _export_json(flow, tasks_list, all_subtasks, output_path)
    if fmt == "markdown":
        return _export_markdown(flow, tasks_list, all_subtasks, output_path)
    if fmt == "html":
        return _export_html(flow, tasks_list, all_subtasks, output_path)
    if fmt == "pdf":
        return await _export_pdf(flow, tasks_list, all_subtasks, output_path)
    # Should be unreachable thanks to the SUPPORTED_FORMATS check above.
    raise ValueError(f"Unsupported format: {format!r}")


# ---------------------------------------------------------------------------
# Format-specific exporters (sync helpers + async PDF wrapper).
# ---------------------------------------------------------------------------


def _export_markdown(
    flow: Any,
    tasks: list[Any],
    subtasks: list[Any],
    output_path: str | None,
) -> bytes:
    """Render the flow report to Markdown bytes."""
    from elengenix.reports.markdown import generate_report_markdown

    md = generate_report_markdown(flow, tasks, subtasks)
    data = md.encode("utf-8")
    if output_path:
        with open(output_path, "wb") as fh:
            fh.write(data)
    return data


def _export_html(
    flow: Any,
    tasks: list[Any],
    subtasks: list[Any],
    output_path: str | None,
) -> bytes:
    """Render the flow report to a self-contained HTML document."""
    from elengenix.reports.markdown import generate_report_markdown

    md = generate_report_markdown(flow, tasks, subtasks)
    html = render_html(md, include_css=True)
    data = html.encode("utf-8")
    if output_path:
        with open(output_path, "wb") as fh:
            fh.write(data)
    return data


def _export_json(
    flow: Any,
    tasks: list[Any],
    subtasks: list[Any],
    output_path: str | None,
) -> bytes:
    """Render the flow report to a structured JSON payload."""
    payload = render_json_payload(flow, tasks, subtasks)
    data = json.dumps(payload, indent=2, ensure_ascii=False, default=str).encode("utf-8")
    if output_path:
        with open(output_path, "wb") as fh:
            fh.write(data)
    return data


async def _export_pdf(
    flow: Any,
    tasks: list[Any],
    subtasks: list[Any],
    output_path: str | None,
) -> bytes:
    """Render the flow report to a PDF document.

    ReportLab is synchronous; we run it via :func:`asyncio.to_thread`
    so the event loop is not blocked during the (CPU-bound) PDF build.
    """
    from elengenix.reports.markdown import generate_report_markdown
    from elengenix.reports.pdf import render_to_pdf, render_to_pdf_bytes

    md = generate_report_markdown(flow, tasks, subtasks)
    if output_path:
        path = await asyncio.to_thread(render_to_pdf, md, output_path)
        with open(path, "rb") as fh:
            return fh.read()
    return await asyncio.to_thread(render_to_pdf_bytes, md)


__all__ = [
    "SUPPORTED_FORMATS",
    "FlowDataProvider",
    "export_report",
    "generate_filename",
    "render_html",
    "render_json_payload",
]
